[![Vault Demo](https://github.com/sidd-harth-7/actions-1/actions/workflows/vault-demo.yml/badge.svg)](https://github.com/sidd-harth-7/actions-1/actions/workflows/vault-demo.yml)

[![Exploring Variables and Secrets](https://github.com/sidd-harth-7/actions-1/actions/workflows/variable-secrets.yml/badge.svg)](https://github.com/sidd-harth-7/actions-1/actions/workflows/variable-secrets.yml)

# Exploring Actions
We will be learning GitHub Actions, 
- a robust automation tool that empowers you to streamline repetitive tasks
- automate your software development workflows
- enhancing productivity and code quality

We made some changes in README
